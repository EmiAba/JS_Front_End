 const baseUrl='http://localhost:3030/jsonstore/tasks/';

 const buttonLoadHisotryElement=document.getElementById('load-history');

 const locationInputElement = document.getElementById('location');
const temperatureInputElement = document.getElementById('temperature');
const dateInputElement = document.getElementById('date');

const watherListElement=document.getElementById('list');
const editButtonWeather=document.getElementById('edit-weather');
const addButtonWeather=document.getElementById('add-weather');
const formElement=document.getElementById('form');


const loadWeather=async ()=>{

    const response=  await fetch(baseUrl);
    const data = await response.json();

    watherListElement.innerHTML='';

    for (const weather of Object.values(data)) {

        const changeButtonElement = document.createElement('button');
        changeButtonElement.textContent = 'Change';
        changeButtonElement.classList.add('change-btn');


        const deleteButtonElement = document.createElement('button');
        deleteButtonElement.textContent = 'Delete';
        deleteButtonElement.classList.add('delete-btn');

        const buttonContainerElement = document.createElement('div');
        buttonContainerElement.classList.add('buttons-container');
        buttonContainerElement.appendChild(changeButtonElement);
        buttonContainerElement.appendChild(deleteButtonElement);

        const loacationH1Elements=document.createElement('h1');
        loacationH1Elements.textContent=weather.location;

        const temperatureH3Element=document.createElement('h3');
        temperatureH3Element.textContent=weather.temperature;

        const dateH3Element=document.createElement('h3');
        dateH3Element.textContent=weather.date;

        const weatherDataContainer=document.createElement('div');
        weatherDataContainer.classList.add('container');



        weatherDataContainer.appendChild(loacationH1Elements);
        weatherDataContainer.appendChild(dateH3Element);
        weatherDataContainer.appendChild(temperatureH3Element);
       
        weatherDataContainer.appendChild(buttonContainerElement);
        watherListElement.appendChild(weatherDataContainer);

        editButtonWeather.setAttribute('disabled', 'disabled');

//change data
        changeButtonElement.addEventListener('click', async()=>{
         formElement.setAttribute('data-id', weather._id);

        locationInputElement.value=weather.location;
        temperatureInputElement.value=weather.temperature;
        dateInputElement.value=weather.date;

            editButtonWeather.removeAttribute('disabled');
            addButtonWeather.setAttribute('disabled', 'disabled');

            weatherDataContainer.remove();

        });

        //delete button information
        deleteButtonElement.addEventListener('click', async()=>{

      const response= await fetch(`${baseUrl}/${weather._id}`, {
                method: 'DELETE'
            });
            if (!response.ok) {
                console.error('Failed to delete');
                return;
            }
            // remove from list
            weatherDataContainer.remove();      

            await loadWeather();
      
        });




    }


 }



 buttonLoadHisotryElement.addEventListener('click', loadWeather);

 editButtonWeather.addEventListener('click', async () => {
    // get data from inputs
    const { location, date, temperature } = getInputData();

    // get meal id
    const watherId = formElement.getAttribute('data-id');

    // make a put request
    const response = await fetch(`${baseUrl}/${watherId}`, {
        method: 'PUT',
        headers: {
            'content-type': 'application/json',
        },
        body: JSON.stringify({
            _id: watherId,
            location,
            date,
            temperature,
        })
    });

    if (!response.ok) {
        return;
    }

    // deactivate edit button
   editButtonWeather.setAttribute('disabled', 'disabled');

    // activate addbutton
   addButtonWeather.removeAttribute('disabled');

    // clear currentMealId
    formElement.removeAttribute('data-id');

    // clear inputs fields
    clearInputData();
    
    // load weather
    loadWeather();
});






addButtonWeather.addEventListener('click', async()=>{
  

    const newData = getInputData();
    const response = await fetch(baseUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(newData),
    });

    if (!response.ok) {
        console.error('Failed to add new weather data');
        return;
    }
    clearInputData();

  loadWeather();
})


 function getInputData() {
const location= locationInputElement.value;
const date= dateInputElement.value;
const temperature=temperatureInputElement.value; 
   

    return { location, date, temperature };
}

function clearInputData() {
    locationInputElement.value = '';
    dateInputElement.value = '';
    temperatureInputElement.value = '';
}